/*
 * Simple Program with a few Errors corrected.
 * (CSC450_CT1_mod1_1.cpp)
 */

#include <iostream>
#include <conio.h>

// Standard namespace declaration
using namespace std;

// Main Function
int main() {

    //Standard Output Statement
    cout << "Welcome to this C++ Program." << endl;

    cout << "I have corrected all errors for this program." << endl;

    // Wait For Output Screen
    getch();

    // Function return Statement
    return 0;

}
