/*
 * Simple Program with a few Errors corrected.
 * (CSC450_CT1_mod1_2.cpp)
 */

#include <iostream>
#include <iomanip>
#include <conio.h>

// Standard namespace declaration
using namespace std;

// Main Function
int main() {

    //this should be printed out
    double myMoney = 1000.50;


    // Standard Output Statement
    cout << "Please be sure to correct all syntax errors in this program." << endl;

    cout << "I have corrected all errors for this program." << endl;

    cout << "The total amount of money available is ";
    cout << setprecision(2) << fixed << "$" << myMoney << endl;

    // Wait for Output Screen
    getch();

    // Function return Statement
    return 0;
}
